To run the program -
	g++ tsp_first_try.cpp -o TSP --std=c++11
	./TSP <inputfile> <outputfile>